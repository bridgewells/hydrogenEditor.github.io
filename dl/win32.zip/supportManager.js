
let com = {
	'v3':{
		'sessionManager':sessionManager,
		'disableEditor':disable_editor,
		'enableEditor':enable_editor,
		'generateUKey':generateUKey,
		'createFile':createWSItem,
		'createBreadCrumb':createBreadCrumb,
		'notification':{
			'information':changeStatus,
			'warning':changeStatusNegative
		},
		'showSearchResults':showSearchResults,
		'createItemPanel':createItemPanel,
		'saveAllUnsaved':saveAllUnsaved,
		'refreshTree':refreshTree,
		'eventManager':eventManager
	}
}